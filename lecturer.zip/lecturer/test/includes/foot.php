
<!--Start footer-->
<!-- <footer class="footer">
    <div class="container">
    <div class="text-center">
        Copyright © 2023 Fountain University, PG
    </div>
    </div>
</footer> -->
<!--End footer-->



<script src="../assets/js/popper.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>

<!-- simplebar js -->
<script src="../assets/js/waves.js"></script>
<script src="../assets/js/sidebar-menu.js"></script>
<script src="../assets/js/app-script.js"></script>
<script src="../assets/js/sidebar-menu.js"></script>
<script src="../assets/plugins/simplebar/js/simplebar.js"></script>
<!-- Custom scripts -->

<!--wizard initialization-->

<script src="../assets/plugins/jquery.steps/js/jquery.steps.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery.steps/js/jquery.wizard-init.js" type="text/javascript"></script>

<!--notification js -->
<script src="../assets/plugins/notifications/js/lobibox.min.js"></script>
<script src="../assets/plugins/notifications/js/notifications.min.js"></script>
<script src="../assets/plugins/notifications/js/notification-custom-script.js"></script>