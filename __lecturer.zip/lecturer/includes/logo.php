<div class="text-center">
    <img src="../assets/images/fuo_logo2.jpeg">
</div>