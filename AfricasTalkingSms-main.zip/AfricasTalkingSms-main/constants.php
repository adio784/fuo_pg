<?php
   define('USERNAME', 'ENTER_USERNAME_HERE');
   define('APIKEY', 'ENTER_APIKEY_HERE'); 