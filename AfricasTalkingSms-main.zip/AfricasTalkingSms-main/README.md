# AfricasTalkingSms APi
![Screen shot](images/screenshot-shot.png)
Enter your Africas' Talking APi Key and username on constants.php
